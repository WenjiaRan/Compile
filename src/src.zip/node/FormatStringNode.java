package node;

public class FormatStringNode {
}
