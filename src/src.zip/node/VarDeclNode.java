package node;

public class VarDeclNode {
}
