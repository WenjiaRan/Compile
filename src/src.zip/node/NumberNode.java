package node;

public class NumberNode {
}
