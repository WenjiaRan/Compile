package node;

public class ConstDefNode {
}
