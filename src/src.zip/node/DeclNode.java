package node;

public class DeclNode {
}
