package node;

public class IntConstNode {
}
