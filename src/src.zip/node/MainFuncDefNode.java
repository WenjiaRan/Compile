package node;

public class MainFuncDefNode {
}
