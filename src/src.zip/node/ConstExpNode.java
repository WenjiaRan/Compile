package node;

public class ConstExpNode {
}
