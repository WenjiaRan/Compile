package node;
import frontend.Parser;
import token.Token;
import utils.IOUtils;

import java.util.List;
public class AddExpNode {
    //AddExp → MulExp | AddExp ('+' | '−') MulExp
    // 解决左递归
    // MulExp {('+' | '−') MulExp}
    // 没有回溯
    private List<MulExpNode> mulExpNodes;
    private List<Token> operations;

    public AddExpNode(List<MulExpNode> mulExpNodes, List<Token> operations) {
        this.mulExpNodes = mulExpNodes;
        this.operations = operations;
    }

    public void print() {
        for (int i = 0; i < mulExpNodes.size(); i++) {
            mulExpNodes.get(i).print();
            // 输出+-符号
            if (i < operations.size()) {
                IOUtils.write(operations.get(i).toString());
            }
        }
        IOUtils.write(Parser.nodeType.get(NodeType.AddExp));
    }
}
