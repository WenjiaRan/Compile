package node;

public class IdentNode {
}
