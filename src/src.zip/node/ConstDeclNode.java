package node;

public class ConstDeclNode {
}
