package node;

public class FuncDefNode {
}
