package node;

public class FuncFParamNode {
}
