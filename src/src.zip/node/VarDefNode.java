package node;

public class VarDefNode {
}
