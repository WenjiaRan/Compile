package node;

public class InitValNode {
}
