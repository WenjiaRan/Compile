package node;

public class BTypeNode {
}
