package node;
import  frontend.Parser;
import token.Token;
import utils.IOUtils;
import java.util.List;
public class UnaryExpNode {
    // UnaryExp → PrimaryExp | Ident '(' [FuncRParams] ')'| UnaryOp UnaryExp
    // 无左递归
    // PrimaryExp → '(' Exp ')' | LVal | Number
    // LVal → Ident {'[' Exp ']'} //1.普通变量 2.一维数组 3.二维数组
    // Number → IntConst 数字
    // UnaryOp → '+' | '−' | '!' 注：'!'仅出现在条件表达式中


    // First(PrimaryExp) = {'(',Ident, Number}
    // First(Ident) = {Ident}
    // First(UnaryOp) ={ '+', '-', '!'}
    // 有回溯
    // UnaryExp → Number |'(' Exp ')' | Ident  ( '(' [FuncRParams] ')'| {'[' Exp ']'})| UnaryOp UnaryExp

}
