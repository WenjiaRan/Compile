package node;

public class FuncTypeNode {
}
