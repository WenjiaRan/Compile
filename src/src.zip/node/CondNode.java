package node;

public class CondNode {
}
