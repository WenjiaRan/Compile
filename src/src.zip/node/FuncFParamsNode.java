package node;

public class FuncFParamsNode {
}
