package node;

public class ConstInitValNode {
}
