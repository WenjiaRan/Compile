package node;

public class LValNode {
}
