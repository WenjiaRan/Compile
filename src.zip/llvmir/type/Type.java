package llvmir.type;

public class Type {
}
