package llvmir.type;

public class VoidType extends Type {
    public static VoidType voidType=new VoidType();;
}
