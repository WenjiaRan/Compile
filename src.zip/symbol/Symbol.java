package symbol;

public class Symbol {
    public String name;
}
