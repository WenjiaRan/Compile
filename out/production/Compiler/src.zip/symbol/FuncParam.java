package symbol;

public class FuncParam {
    public String name;//参数名
    public int dimension;//参数维度

    public FuncParam(String name, int dimension) {
        this.name = name;
        this.dimension = dimension;
    }
}
