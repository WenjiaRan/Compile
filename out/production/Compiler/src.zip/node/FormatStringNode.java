package node;

import token.Token;

public class FormatStringNode {

}
